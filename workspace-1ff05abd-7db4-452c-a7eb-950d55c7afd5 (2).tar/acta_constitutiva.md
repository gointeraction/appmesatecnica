# MESA TÉCNICA DE CRIPTOACTIVOS Y COMERCIO ELECTRÓNICO {#mesa-técnica-de-criptoactivos-y-comercio-electrónico .unnumbered}

## CÁMARA VENEZOLANA DE COMERCIO ELECTRÓNICO (CAVECOM-e) {#cámara-venezolana-de-comercio-electrónico-cavecom-e .unnumbered}

**Código de Sesión:** [CAVECOM- DNC-MTC-001-2026]{.mark}

**Carácter:** Constitutiva y Resolutoria **Modalidad:** Híbrida
(Presencial / Virtual) **Duración:** 120 minutos

# DATOS GENERALES DE LA SESIÓN

En la ciudad de Caracas, a los 19 días del mes de Marzo del año 2026,
siendo las 10 horas, se dio inicio a la **Primera Sesión Plenaria
Constitutiva de la Mesa Técnica de Criptoactivos y Comercio
Electrónico**, convocada por la **Cámara Venezolana de Comercio
Electrónico (CAVECOM-e)**, de conformidad con la Hoja de Ruta Integral y
el Protocolo de Instalación aprobados por la institución.

La sesión se desarrolló en modalidad híbrida, con participación
presencial en la sede de CAVECOM-e y conexión virtual a través de la
plataforma corporativa autorizada.

# INSTALACIÓN FORMAL DE LA MESA TÉCNICA

La sesión fue abierta por el **Presidente de CAVECOM-e**, quien realizó
la lectura de la justificación institucional para la creación de la Mesa
Técnica, destacando:

-   La creciente adopción de criptoactivos en el comercio electrónico
    venezolano.

-   Los riesgos legales, fiscales, contables y tecnológicos derivados de
    una adopción no estandarizada.

-   El rol estratégico de CAVECOM-e como ente articulador y promotor de
    la economía digital y del ecosistema cripto venezolano.

Acto seguido, se declaró **formalmente instalada la Mesa Técnica de
Criptoactivos de CAVECOM-e**, con carácter permanente, consultivo,
técnico y estratégico.

# CONSTITUCIÓN DE LA ESTRUCTURA DE GOBERNANZA

Bajo la conducción del **Presidente de CAVECOM-e**, se procedió a la
constitución formal de la estructura de gobernanza de la Mesa Técnica,
quedando conformada de la siguiente manera:

## Consejo Directivo de la Mesa Técnica (CDMT)

-   **Presidencia:** Presidente de Cavecom-e

-   **Coordinación Nacional integrada por:**

    -   Junta Directiva Nacional de Cavecom-e.

    -   Director Nacional de criptoactivos.

    -   Directores Regionales de criptoactivos.

-   **Secretario Técnico**: Se designará por consenso**.**

El Consejo Directivo de la Mesa Técnica CDMT queda investido con
funciones estratégicas, decisorias y de validación institucional.

## Comités Especializados

Se aprobaron y designaron los siguientes comités:

### Comité Legal y Regulatorio

-   Líder del Comité:

-   Perfil: Abogado

### Comité de Tecnología

-   Líder del Comité:

-   Perfil: Especialista en blockchain / Especialistas en inteligencia
    artificial.

a)  **Comité de Modelos de Negocios** *(rol consultivo, no comercial)*

-   Perfil: Profesionales con experiencia en criptoactivos.

b)  **Comité Contable y Tributario** *(rol consultivo, no comercial)*

-   Perfil: Contador Senior especializado en fintech, NIIF y tributación
    digital.

c)  **Comité Académico** *(rol consultivo, no comercial)*

-   Perfil: Profesores especializados en la materia.

### Comité Ciberseguridad, delitos informáticos y legitimación de capitales

-   Líder del Comité:

-   Perfil: Especialista en ciberseguridad, técnicos informáticos y
    Oficiales de Cumplimiento.

### Comité minería de criptoactivos

-   Líder del Comité:

-   Perfil: Especialista en minerías de criptoactivos.

# APROBACIÓN DEL MARCO ÉTICO Y DE NEUTRALIDAD

Se procedió a la lectura y aprobación del **[Régimen]{.mark} de
Consultoría Ad Honorem y Manejo de Conflictos de Interés**, quedando
establecido que:

-   La participación de expertos y empresas proveedoras tendrá carácter
    técnico y no comercial.

-   No se permitirá promoción directa o indirecta de marcas dentro de
    las deliberaciones de la Mesa.

-   La Mesa Técnica actuará como espacio de definición de estándares,
    criterios y buenas prácticas.

Se adoptó como principio rector la siguiente regla institucional:

> *"En la Mesa Técnica se discuten soluciones y estándares; la
> comercialización ocurre fuera de este espacio, bajo las reglas de la
> libre competencia."*

# ACTIVACIÓN DE LAS LÍNEAS OPERATIVAS

## Plan Académico Trimestral (Q1)

Fueron aprobadas las siguientes actividades formativas iniciales:

-   **Master Class:** Marco Regulatorio y Fiscalidad de los
    Criptoactivos en Venezuela.

-   **Podcast Institucional Piloto:** Debate técnico USDT vs USDC.

-   **Taller Especializado:** Ciberseguridad y Custodia de Criptoactivos
    (wallets frías vs calientes).

## Sistema de Asesoría Técnica

Se aprobó el flujo de atención de consultas técnicas para empresas
afiliadas a CAVECOM-e, estableciendo los siguientes SLA:

-   Consultas informativas: desde 48 y hasta 72 horas.

-   Dictámenes técnicos complejos: entre 5 y 7 días hábiles.

Las consultas serán canalizadas por el Secretario Técnico y asignadas al
comité correspondiente.

# ACUERDOS FINALES

Como resultado de la presente sesión, se acordó:

1.  Dar inicio inmediato a las operaciones de la Mesa Técnica.

2.  Autorizar al Secretario Técnico a emitir las actas, boletines y
    comunicaciones oficiales.

3.  Convocar la próxima sesión ordinaria mensual en fecha a ser
    notificada.

4.  Lanzar el formulario diagnóstico dirigido a las empresas afiliadas
    de CAVECOM-e.

# CIERRE DE LA SESIÓN

No habiendo otros puntos que tratar, y siendo las horas, se dio por
concluida la sesión, dejando constancia de que la presente **[Acta de
Instalación]{.mark}** refleja fielmente las decisiones adoptadas y
servirá como documento fundacional de la Mesa Técnica de Criptoactivos y
Comercio Electrónico de CAVECOM-e.

# FIRMAS

En señal de conformidad, firman:

### Presidente CAVECOM-e {#presidente-cavecom-e .unnumbered}

Nombre:

Firma:

**Por la Junta Directiva Nacional CAVECOM-e**

Nombre: Firma:

### Secretario Técnico de la Mesa {#secretario-técnico-de-la-mesa .unnumbered}

Nombre:

Firma:

*Documento institucional. Uso exclusivo de CAVECOM-e.*
