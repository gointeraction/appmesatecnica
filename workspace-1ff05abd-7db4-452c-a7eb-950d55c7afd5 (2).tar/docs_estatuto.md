# **MESA TÉCNICA DE CRIPTOACTIVOS Y COMERCIO ELECTRÓNICO**

**CÁMARA VENEZOLANA DE COMERCIO ELECTRÓNICO (CAVECOM-e)**

# **CAPÍTULO I**

## **DISPOSICIONES GENERALES**

### **Cláusula 1. Naturaleza**

La Mesa Técnica de Criptoactivos y Comercio Electrónico de CAVECOM-e, en
adelante la Mesa Técnica, es una unidad institucional permanente, de
carácter técnico, consultivo, estratégico y no comercial, adscrita a la
Cámara Venezolana de Comercio Electrónico (CAVECOM-e).

**Cláusula 2. Finalidad**

La Mesa Técnica tiene como finalidad reducir riesgos legales, fiscales,
contables y tecnológicos asociados al uso de criptoactivos, establecer
estándares gremiales de adopción responsable y fortalecer la
competitividad del comercio electrónico venezolano.

### **Cláusula 3. Marco de actuación** 

### La Mesa Técnica actuará conforme a la Hoja de Ruta Integral aprobada por CAVECOM-e, al presente Estatuto, a su Acta Constitutiva y a las decisiones emanadas de la Junta Directiva de la Cámara.

# **CAPÍTULO II**

## **OBJETIVOS Y FUNCIONES**

### **Cláusula 4. Objetivos Específicos**

La operatividad de la Mesa Técnica se fundamenta en la consecución de
los siguientes objetivos estratégicos y técnicos:

1.  **Asistencia Técnica Especializada:** Proveer soporte consultivo de
    alto nivel a las empresas afiliadas, garantizando la resolución de
    nudos críticos en sus procesos operativos y legales.

2.  **Generación de Doctrina Institucional:** Emitir criterios técnicos
    y dictámenes institucionales que sirvan de base para la toma de
    decisiones y la unificación de posturas gremiales.

3.  **Capacitación de Alto Impacto:** Diseñar y ejecutar programas de
    formación continua y especializada que fortalezcan las competencias
    del capital humano en el sector digital.

4.  **Inteligencia Regulatoria y Tecnológica:** Establecer sistemas de
    monitoreo proactivo para identificar, analizar y mitigar riesgos
    derivados de cambios normativos o disrupciones tecnológicas.

5.  **Liderazgo de Pensamiento:** Consolidar el posicionamiento de
    CAVECOM-e como el máximo referente nacional y órgano de consulta
    obligatoria en materia de economía digital

**Cláusula 5. Funciones**

Para dar cumplimiento a los objetivos previstos, la Mesa Técnica
ejercerá las siguientes funciones sistemáticas:

1.  **Auditoría y Análisis Normativo:** Realizar el estudio exhaustivo
    de los marcos regulatorios, fiscales y legales, evaluando su impacto
    directo en el ecosistema del comercio electrónico.

2.  **Gestión de Seguridad y Resiliencia:** Evaluar de forma permanente
    los protocolos de ciberseguridad, mecanismos de custodia y
    protección de datos para garantizar la integridad operativa de los
    afiliados.

3.  **Estandarización de Procesos:** Proponer y validar estándares
    técnicos y operativos que promuevan la interoperabilidad y la ética
    en las transacciones digitales.

4.  **Difusión de Conocimiento Técnico:** Elaborar boletines periódicos,
    guías de buenas prácticas y recomendaciones técnicas que orienten el
    desempeño eficiente de las empresas del sector.

# 

# **CAPÍTULO III**

## **ESTRUCTURA DE GOBERNANZA**

### **Cláusula 6. Consejo Directivo de la Mesa (CDM)**

### El Consejo Directivo de la Mesa (CDM) se constituye como el órgano superior de carácter estratégico, técnico y decisorio. Es el encargado de establecer las directrices fundamentales, asegurar la alineación de los objetivos de la Mesa Técnica con la visión institucional y garantizar la eficiencia operativa del sistema de gestión.

**Cláusula 7. Funciones Sistémicas y Operativas:** Para el correcto
ejercicio de sus facultades, el CDM asumirá las siguientes
responsabilidades:

1.  **Dirección Estratégica:** Definir la hoja de ruta y los planes de
    acción a corto, mediano y largo plazo.

2.  **Potestad Decisoria:** Validar y aprobar las propuestas emanadas de
    los equipos técnicos, resolviendo cualquier conflicto de competencia
    o interpretación normativa.

3.  **Supervisión y Control:** Evaluar el cumplimiento de los
    indicadores de gestión (KPIs) y el impacto de los resultados
    obtenidos por la Mesa.

4.  **Representación Institucional:** Actuar como el interlocutor
    oficial ante entes externos y niveles superiores de la
    administración.

**Cláusula 8. Integración y Quórum:** El CDM estará integrado por
miembros con alta capacidad técnica y liderazgo, cuya selección
responderá a criterios de idoneidad y especialización. Sus sesiones se
regirán por principios de colegialidad, requiriendo un quórum
reglamentario para la validez de sus acuerdos, los cuales serán de
obligatorio cumplimiento para todos los niveles de la estructura.

### **Cláusula 9. Composición del Consejo Directivo de la Mesa (CDM)**

La estructura de gobernanza del Consejo Directivo de la Mesa (CDM)
estará integrada de manera colegiada por los siguientes miembros,
quienes velarán por el cumplimiento de los fines institucionales:

1.  **Presidencia:** Ejercida por el **Presidente de Cavecom-e** o, en
    su defecto, por el delegado que este designe formalmente. El
    Presidente del CDM ostenta la representación máxima del órgano,
    dirige las sesiones y posee la facultad de dirimir empates mediante
    el voto de calidad. Su gestión garantiza la alineación estratégica
    con las políticas nacionales del sector.

2.  **Representante de la Junta Directiva de CAVECOM-e:** Designado
    directamente por la Junta Directiva de la Cámara Venezolana de
    Comercio Electrónico. Su función principal es actuar como enlace
    permanente entre los lineamientos gremiales y las decisiones de la
    Mesa Técnica, asegurando que los intereses de los afiliados y la
    visión de la Cámara se mantengan como eje central de las decisiones
    decisorias.

3.  **Secretaría Técnica:** Actuará como el órgano de soporte
    administrativo y operativo del CDM. El Secretario Técnico tendrá la
    responsabilidad de custodiar las actas de las sesiones, gestionar el
    flujo de información entre las comisiones, dar seguimiento al
    cumplimiento de los acuerdos y coordinar la elaboración de los
    boletines y dictámenes institucionales previstos en el régimen.

### **Cláusula 10. Funciones del Consejo Directivo de la Mesa (CDM)**

En su condición de órgano superior de dirección, el Consejo Directivo de
la Mesa (CDM) ejercerá las siguientes atribuciones y responsabilidades:

1.  **Planificación y Gestión Estratégica:** Aprobar y evaluar los
    Planes Operativos Trimestrales, asegurando que los recursos y
    acciones de la Mesa Técnica estén alineados con los objetivos
    estratégicos de la Cámara y el dinamismo del sector de
    criptoactivos.

2.  **Rectoría de Vocería Institucional**: Validar y autorizar las
    vocerías institucionales y los comunicados oficiales emanados de la
    Mesa. El Presidente de la Mesa Técnica (o su delegado formal) es el
    único vocero autorizado para emitir declaraciones públicas,
    institucionales o técnicas sobre criptoactivos en representación de
    CAVECOM-e, previo consenso con el Consejo Directivo de la Mesa
    (CDM).

3.  **Supervisión de Comités Especializados**: Ejercer la tutela,
    control y seguimiento de los Comités Especializados. El CDM tiene la
    potestad de designar a los coordinadores de dichos comités, revisar
    sus avances técnicos y disolver o crear nuevas mesas de trabajo
    según las necesidades del ecosistema digital.

4.  **Ratificación de Instrumentos de Alto Impacto:** Analizar y
    aprobar, en última instancia, los Dictámenes, Guías y
    Recomendaciones Técnicas que por su naturaleza tengan un impacto
    significativo en el marco regulatorio, fiscal o tecnológico del
    país. Ningún dictamen tendrá carácter oficial sin la rúbrica de la
    directiva del CDM.

# **CAPÍTULO IV**

## **COMITÉS ESPECIALIZADOS**

**Artículo 11. Naturaleza y Clasificación de los Comités Permanentes**

Los Comités Especializados son órganos de ejecución técnica y asesoría
permanente, encargados de la generación de conocimiento y soluciones
sectoriales. Se establecen las siguientes unidades:

1.  **Comité de Regulación y Fiscalidad:** Responsable del estudio,
    interpretación y propuesta de mejoras al marco normativo vigente,
    así como del análisis del impacto de las cargas tributarias en la
    economía digital.

2.  **Comité de Tecnología y Ciberseguridad:** Encargado de la
    evaluación de infraestructuras críticas, protocolos de resiliencia
    digital, auditoría de sistemas y mitigación de riesgos tecnológicos
    para el ecosistema.

3.  **Comité de Negocios y Medios de Pago (Rol Consultivo):** Actúa como
    órgano asesor en la integración de nuevas pasarelas de pago, modelos
    de monetización y facilitación de intercambios comerciales dentro y
    fuera de la plataforma digital.

**Artículo 12. Facultades y Responsabilidades Operativas**

Los comités, en el ejercicio de sus competencias técnicas, tendrán las
siguientes funciones primordiales:

1.  **Análisis de Consultas Especializadas:** Atender y resolver los
    requerimientos técnicos asignados por el Consejo Directivo de la
    Mesa (CDM) o las solicitudes elevadas por las empresas afiliadas.

2.  **Gestión Documental y Técnica:** Elaborar informes, estudios de
    mercado y dictámenes técnicos fundamentados que sirvan de insumo
    para la toma de decisiones estratégicas del CDM.

3.  **Normalización y Estandarización:** Proponer estándares operativos,
    protocolos de seguridad y códigos de buenas prácticas que propendan
    a la profesionalización y armonización del sector.

4.  **Investigación y Desarrollo (I+D):** Mantener un monitoreo
    constante sobre las tendencias globales para proponer innovaciones
    que mantengan la competitividad de la Cámara.

# **CAPÍTULO V**

## **SECRETARÍA TÉCNICA**

**Artículo 13. Atribuciones y Responsabilidades del Secretario Técnico**

La Secretaría Técnica se constituye como el órgano de apoyo ejecutivo,
administrativo y de fe pública interna de la Mesa Técnica. Para
garantizar la continuidad operativa y el orden institucional, ejercerá
las siguientes funciones:

1.  **Gestión de Convocatorias y Agenda:** Coordinar y formalizar la
    convocatoria a las sesiones ordinarias y extraordinarias del Consejo
    Directivo de la Mesa (CDM), previa instrucción de la Presidencia o
    Vicepresidencia, asegurando la entrega oportuna del orden del día y
    los materiales de soporte.

2.  **Fe Pública y Documentación Oficial:** Elaborar, suscribir y
    resguardar las actas de cada sesión, así como certificar los
    acuerdos, resoluciones y documentos oficiales emanados de la Mesa.
    Es el responsable de transformar las deliberaciones en instrumentos
    jurídicos y administrativos válidos.

3.  **Administración del Sistema de Consultas:** Gestionar el flujo de
    entrada y salida de las solicitudes técnicas, asignándolas a los
    comités correspondientes según su naturaleza y realizando el
    seguimiento riguroso de los plazos de respuesta para garantizar la
    eficiencia del servicio a los afiliados.

4.  **Custodia y Acervo Institucional:** Organizar y mantener el archivo
    histórico y técnico de la Mesa, asegurando la confidencialidad,
    integridad y disponibilidad de la documentación institucional
    mediante sistemas de archivo físico y digital.

5.  **Enlace Operativo:** Servir de puente de comunicación permanente
    entre el CDM, los Comités Especializados y la estructura
    administrativa de CAVECOM-e.

### **CAPÍTULO VI**

### **DEL RÉGIMEN ÉTICO Y LA NEUTRALIDAD INSTITUCIONAL**

**Artículo 14. Principio de Neutralidad y Objetividad Técnica**

La Mesa Técnica se rige por el principio de neutralidad absoluta. En
consecuencia, queda estrictamente prohibido utilizar el espacio, los
recursos o los dictámenes de la Mesa para la promoción, publicidad o
favorecimiento de marcas, productos o servicios comerciales específicos.
Toda recomendación técnica debe fundamentarse en estándares universales,
mejores prácticas internacionales y criterios de idoneidad tecnológica,
garantizando la igualdad de condiciones para todo el ecosistema de la
economía digital.

**Artículo 15. Carácter Ad Honorem y Ausencia de Conflictos de Interés**

La participación de expertos, asesores y representantes de empresas en
la Mesa Técnica y sus comités tendrá carácter estrictamente profesional
y **ad honorem**.

1.  **Independencia Operativa:** La colaboración técnica no genera
    relación comercial directa, privilegios contractuales ni vínculos
    laborales con CAVECOM-e.

2.  **Declaración de Intereses:** Los miembros se comprometen a actuar
    en beneficio del interés gremial y nacional, debiendo inhibirse de
    participar en deliberaciones donde pueda existir un conflicto entre
    sus intereses privados y la objetividad del dictamen técnico
    requerido.

**Artículo 16. Confidencialidad y Manejo de Información Privilegiada**

Toda información estratégica, datos sensibles de afiliados o proyectos
normativos en fase de diseño conocidos en el seno de la Mesa Técnica,
tienen carácter confidencial. Su divulgación no autorizada será
considerada una falta grave a la ética institucional.

### **CAPÍTULO VII**

### **DEL SISTEMA DE ASESORÍA TÉCNICA Y OPERATIVA**

**Artículo 17. Protocolo de Gestión y Flujo de Atención**

Para garantizar la trazabilidad y la excelencia en el soporte técnico,
la Mesa Técnica adopta un modelo de gestión basado en procesos, el cual
se ejecutará mediante las siguientes etapas secuenciales:

1.  **Recepción:** Ingreso formal de la solicitud a través de los
    canales oficiales gestionados por la Secretaría Técnica.

2.  **Clasificación:** Evaluación inmediata de la consulta para
    determinar su naturaleza (Legal, Fiscal, Tecnológica o de Negocios)
    y su nivel de criticidad.

3.  **Asignación:** Derivación del caso al Comité Especializado
    correspondiente o al experto designado según la materia.

4.  **Dictamen:** Elaboración de la respuesta técnica, informe o
    recomendación debidamente fundamentada.

5.  **Seguimiento y Cierre:** Verificación de la satisfacción del
    afiliado y registro de la solución en la base de conocimientos
    institucional para futuras consultas.

**Artículo 18. Niveles de Servicio (SLA) y Tiempos de Respuesta**

La Mesa Técnica se compromete con la celeridad administrativa,
estableciendo los siguientes plazos máximos de respuesta según la
complejidad del requerimiento:

-   **Consultas Estándar:** Aquellas que versan sobre procedimientos
    operativos existentes o información técnica de libre acceso, tendrán
    un tiempo de respuesta de hasta 72 horas.

-   **Dictámenes Complejos:** Requerimientos que exijan análisis
    jurídico profundo, evaluación de riesgos tecnológicos o deliberación
    del Consejo Directivo (CDM), contarán con un plazo de 5 a 10 días
    hábiles, prorrogables según la magnitud del caso.

### 

### **CAPÍTULO VIII**

### **DEL RÉGIMEN DE SESIONES Y TOMA DE DECISIONES**

**Artículo 19. Periodicidad y Convocatoria de Sesiones Ordinarias** Con
el fin de garantizar un monitoreo constante de los objetivos
estratégicos, la Mesa Técnica celebrará al menos **una (1) sesión
ordinaria mensual**.

1.  **Calendario Anual:** La Secretaría Técnica propondrá un calendario
    de sesiones al inicio de cada semestre para facilitar la
    planificación de los miembros del CDM.

2.  **Sesiones Extraordinarias:** Se podrán convocar sesiones
    extraordinarias en cualquier momento por solicitud de la Presidencia
    o la Vicepresidencia, cuando la urgencia de los temas regulatorios o
    tecnológicos así lo amerite.

**Artículo 20. Quórum y Validez de los Acuerdos** Para que las sesiones
y las decisiones tomadas en ellas tengan validez institucional, se
establecen las siguientes reglas de participación:

1.  **Quórum de Instalación:** Se requerirá la presencia de la **mayoría
    simple** de los miembros del Consejo Directivo de la Mesa (CDM)
    (mitad más uno).

2.  **Adopción de Acuerdos:** Las decisiones se tomarán preferiblemente
    por consenso. En caso de no lograrse, se decidirá por mayoría de
    votos de los presentes. En situaciones de empate, el Presidente (o
    su delegado) ejercerá el **voto de calidad** para dirimir la
    controversia.

3.  **Participación Virtual:** Se reconoce la validez de las sesiones
    realizadas a través de medios telemáticos, siempre que se garantice
    la identificación y participación activa de los miembros, quedando
    registro de ello en el acta correspondiente.

# **CAPÍTULO IX**

## **MODIFICACIONES Y VIGENCIA DEL REGIMEN**

**Artículo 21. Procedimiento de Reforma y Actualización** El presente
**Régimen de Funcionamiento** podrá ser objeto de revisiones,
actualizaciones o modificaciones integrales mediante acuerdo del Consejo
Directivo de la Mesa (CDM). Toda propuesta de reforma deberá ser
sometida a la ratificación de la **Junta Directiva de CAVECOM-e** para
asegurar la alineación con la visión superior de la Cámara antes de su
implementación definitiva.

**Artículo 22. Vigencia y Aplicabilidad** Las disposiciones contenidas
en este instrumento entrarán en vigor a partir de la fecha de su
aprobación formal por las instancias decisorias correspondientes. Su
aplicación será de carácter obligatorio para todos los miembros,
asesores y comités que integran la estructura operativa de la Mesa
Técnica.

### **CAPITULO X**

### **DISPOSICIONES FINALES**

**Cláusula 23. Interpretación y Vacíos Normativos** Cualquier duda en la
interpretación del presente Régimen o situación no prevista en su
articulado, será resuelta de manera soberana por el Consejo Directivo de
la Mesa (CDM), siempre en consulta con la Dirección Legal de CAVECOM-e y
bajo los principios de transparencia y ética institucional.

**Cláusula 23. Aprobación y Resguardo** El presente Régimen se considera
formalmente válido tras su aprobación en Acta de Junta Directiva de
CAVECOM-e. La Secretaría Técnica será responsable de su custodia y de
asegurar que cada miembro de la Mesa Técnica reciba una copia oficial
para su estricto cumplimiento.
